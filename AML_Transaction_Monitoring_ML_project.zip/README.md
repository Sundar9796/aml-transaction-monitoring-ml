# AML Transaction Monitoring – Machine Learning Anomaly Detection

Detecting potentially suspicious (money-laundering) bank transfers with machine learning, and **reducing the false positives** that rules-based transaction monitoring creates.

![Results](aml_results.png)

## Problem
Banks monitor transactions with fixed rules (high-risk country, amounts near a reporting threshold, round amounts, high velocity). These rules catch suspicious activity but generate many **false alerts**, so investigators spend most of their time clearing legitimate customers.

## Data
A **synthetic dataset of 611,270 transfers** across 20,000 accounts, generated in the notebook (no real customer data). It contains:
- normal customer behaviour,
- **legitimate look-alikes** that fool simple rules (payroll batches, near-threshold instalments, legitimate trade with high-risk regions),
- three laundering typologies: **structuring**, **rapid fan-out** and **high-risk corridor layering**,
- **8% label noise**, because not every suspicious case is confirmed.

Suspicious transactions make up only **0.39%** of the data – a realistically imbalanced problem.

## Approach
1. **Feature engineering** – behavioural features used in AML monitoring: 24h/6h transaction velocity and value, repeated near-threshold amounts, deviation from the account's own median amount, counterparty breadth, time of day, round amounts, high-risk jurisdiction.
2. **Rules baseline** – a typical rules engine for comparison.
3. **Models (scikit-learn)** – Logistic Regression and Random Forest with class weights for the imbalance, and **Isolation Forest** for unsupervised anomaly detection.
4. **Evaluation** – precision, recall, PR-AUC and ROC-AUC, comparing false positives **at the same recall** as the rules baseline.

## Results (test set, same recall as rules: 69.7%)
| Approach | Precision | False positives | Reduction vs rules | PR-AUC |
|---|---|---|---|---|
| Rules baseline | 13.0% | 3,365 | – | – |
| Logistic Regression | 20.2% | 1,987 | 41% | 0.15 |
| **Random Forest** | **24.9%** | **1,511** | **55%** | **0.28** |
| Isolation Forest (unsupervised) | 15.7% | 2,704 | 20% | 0.22 |

**The Random Forest catches the same suspicious activity as the rules with 55% fewer false alerts, roughly doubling alert precision.** Velocity and value features (24h sum, 24h/6h counts, deviation from the account's normal amount) are the strongest signals.

## Next steps
Time-based validation, threshold tuning by customer risk segment, graph/network features on counterparties, model monitoring and validation documentation.

## Tech
Python · pandas · NumPy · scikit-learn · matplotlib · Jupyter

*Author: Sundar Nagarajan – Senior Data Analyst (banking, AML & payments data)*
